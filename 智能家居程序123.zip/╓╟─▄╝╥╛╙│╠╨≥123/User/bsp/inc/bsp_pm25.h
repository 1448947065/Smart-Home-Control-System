#ifndef _BSP_PM25_H
#define _BSP_PM25_H
#include "sys.h"

#define PM_TEMP_BUF_LEN 10

//CO2��ȡ����
uint16_t PM_READ(void);

#endif
