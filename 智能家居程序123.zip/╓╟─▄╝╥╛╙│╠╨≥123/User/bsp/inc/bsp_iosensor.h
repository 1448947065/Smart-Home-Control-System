#ifndef _BSP_IOSENSOR_H
#define _BSP_IOSENSOR_H

#include "sys.h"



#define VIBRATE_OUT_GPIO_PIN			GPIO_Pin_11			//VIBRATE_OUT���ź�
#define VIBRATE_OUT_PIN_ID				11
#define VIBRATE_OUT_GPIO_PORT			GPIOA
#define VIBRATE_OUT_GPIO_CLK			RCC_APB2Periph_GPIOA
#define VIBRATE_OUT_FUN_OUT				PAout
#define VIBRATE_OUT_FUN_IN				PAin
#define VIBRATE_OUT_GPIO_MODE			GPIO_Mode_IPU
#define VIBRATE_OUT_ACTIVE_LEVEL		0

#define VIBRATE_OUT_PORT_SRC			GPIO_PortSourceGPIOA
#define VIBRATE_OUT_PIN_SRC				GPIO_PinSource11
#define VIBRATE_OUT_EXTI_LINE			EXTI_Line11
#define VIBRATE_OUT_EXTI_TRIG			EXTI_Trigger_Falling
#define VIBRATE_OUT_EXTI_IRQN			EXTI15_10_IRQn

#define PIR_OUT_GPIO_PIN			GPIO_Pin_14			//PIR_OUT���ź�
#define PIR_OUT_PIN_ID				14
#define PIR_OUT_GPIO_PORT			GPIOG
#define PIR_OUT_GPIO_CLK			RCC_APB2Periph_GPIOG
#define PIR_OUT_FUN_OUT				PGout
#define PIR_OUT_FUN_IN				PGin
#define PIR_OUT_GPIO_MODE			GPIO_Mode_IPD
#define PIR_OUT_ACTIVE_LEVEL		1

#define PIR_OUT_PORT_SRC			GPIO_PortSourceGPIOG
#define PIR_OUT_PIN_SRC				GPIO_PinSource14
#define PIR_OUT_EXTI_LINE			EXTI_Line14
#define PIR_OUT_EXTI_TRIG			EXTI_Trigger_Rising
#define PIR_OUT_EXTI_IRQN			EXTI15_10_IRQn

#define VIBRATE_OUT					VIBRATE_OUT_FUN_IN(VIBRATE_OUT_PIN_ID)
#define PIR_OUT						PIR_OUT_FUN_IN(PIR_OUT_PIN_ID)
#define FIRE_OUT					FIRE_OUT_FUN_IN(FIRE_OUT_PIN_ID)
#define HALL_OUT					HALL_OUT_FUN_IN(FIRE_OUT_PIN_ID)

#define FIRE_OUT_GPIO_PIN			GPIO_Pin_12			//FIRE_OUT���ź�
#define FIRE_OUT_PIN_ID				12
#define FIRE_OUT_GPIO_PORT			GPIOA
#define FIRE_OUT_GPIO_CLK			RCC_APB2Periph_GPIOA
#define FIRE_OUT_FUN_OUT			PAout
#define FIRE_OUT_FUN_IN				PAin
#define FIRE_OUT_GPIO_MODE			GPIO_Mode_IPU
#define FIRE_OUT_ACTIVE_LEVEL		0

#define FIRE_OUT_PORT_SRC			GPIO_PortSourceGPIOA
#define FIRE_OUT_PIN_SRC			GPIO_PinSource12
#define FIRE_OUT_EXTI_LINE			EXTI_Line12
#define FIRE_OUT_EXTI_TRIG			EXTI_Trigger_Falling
#define FIRE_OUT_EXTI_IRQN			EXTI15_10_IRQn

#define HALL_OUT_GPIO_PIN			GPIO_Pin_13			//FIRE_OUT���ź�
#define HALL_OUT_PIN_ID				13
#define HALL_OUT_GPIO_PORT			GPIOC
#define HALL_OUT_GPIO_CLK			RCC_APB2Periph_GPIOC
#define HALL_OUT_FUN_OUT			PCout
#define HALL_OUT_FUN_IN				PCin
#define HALL_OUT_GPIO_MODE			GPIO_Mode_IPU
#define HALL_OUT_ACTIVE_LEVEL		0

#define HALL_OUT_PORT_SRC			GPIO_PortSourceGPIOA
#define HALL_OUT_PIN_SRC			GPIO_PinSource13
#define HALL_OUT_EXTI_LINE			EXTI_Line13
#define HALL_OUT_EXTI_TRIG			EXTI_Trigger_Falling
#define HALL_OUT_EXTI_IRQN			EXTI15_10_IRQn

extern	uint8_t VIBRATE_OUT_flag;
extern	uint8_t	PIR_OUT_flag;
extern	uint8_t FIRE_OUT_flag;
extern	uint8_t HALL_OUT_flag;

void bsp_InitIoSensor(void);
#endif


