#ifndef _BSP_CO2_H
#define _BSP_CO2_H
#include "sys.h"

#define CO2_TEMP_BUF_LEN 10

//CO2��ȡ����
uint16_t CO2_READ(void);
uint8_t getCheckSum(uint8_t *packet);
#endif
