#include "bsp.h"

uint8_t VIBRATE_OUT_flag=0;
uint8_t PIR_OUT_flag=0;
uint8_t FIRE_OUT_flag=0;
uint8_t HALL_OUT_flag=0;

void SENSOR_IO_Init(void);
void EXTI_Sensor_Init(void);


/*
*********************************************************************************************************
*	�� �� ��: bsp_InitIoSensor
*	����˵��: �ߵ͵�ƽ�ʹ�������ʼ������
*	��    �Σ���
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void bsp_InitIoSensor(void)
{
	SENSOR_IO_Init();
	EXTI_Sensor_Init();
}
/*
*********************************************************************************************************
*	�� �� ��: SENSOR_IO_Init
*	����˵��: �ߵ͵�ƽ�ʹ�������ʼ������
*	��    �Σ���
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void SENSOR_IO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
	
	RCC_APB2PeriphClockCmd(VIBRATE_OUT_GPIO_CLK,ENABLE);
	GPIO_InitStructure.GPIO_Pin=VIBRATE_OUT_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode=VIBRATE_OUT_GPIO_MODE;
	
	GPIO_Init(VIBRATE_OUT_GPIO_PORT,&GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(PIR_OUT_GPIO_CLK,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin=PIR_OUT_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode=PIR_OUT_GPIO_MODE;
	
	GPIO_Init(PIR_OUT_GPIO_PORT,&GPIO_InitStructure);
	
	
	RCC_APB2PeriphClockCmd(FIRE_OUT_GPIO_CLK,ENABLE);
	GPIO_InitStructure.GPIO_Pin=FIRE_OUT_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode=FIRE_OUT_GPIO_MODE;
	
	GPIO_Init(FIRE_OUT_GPIO_PORT,&GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(HALL_OUT_GPIO_CLK,ENABLE);
	GPIO_InitStructure.GPIO_Pin=HALL_OUT_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode=HALL_OUT_GPIO_MODE;
	
	GPIO_Init(HALL_OUT_GPIO_PORT,&GPIO_InitStructure);
	
}
/*
*********************************************************************************************************
*	�� �� ��: EXTI_Sensor_Init
*	����˵��: �ߵ͵�ƽ�ʹ������ⲿ�жϳ�ʼ������
*	��    �Σ���
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void EXTI_Sensor_Init(void)
{
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	GPIO_EXTILineConfig(VIBRATE_OUT_PORT_SRC,VIBRATE_OUT_PIN_SRC);
	
	
	EXTI_InitStructure.EXTI_Line=VIBRATE_OUT_EXTI_LINE;
	EXTI_InitStructure.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger=VIBRATE_OUT_EXTI_TRIG;
	EXTI_InitStructure.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel=VIBRATE_OUT_EXTI_IRQN;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0x02;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0x02;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	GPIO_EXTILineConfig(PIR_OUT_PORT_SRC,PIR_OUT_PIN_SRC);
	
	EXTI_InitStructure.EXTI_Line=PIR_OUT_EXTI_LINE;
	EXTI_InitStructure.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger=PIR_OUT_EXTI_TRIG;
	EXTI_InitStructure.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel=PIR_OUT_EXTI_IRQN;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0x02;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0x02;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	
	
	GPIO_EXTILineConfig(FIRE_OUT_PORT_SRC,VIBRATE_OUT_PIN_SRC);
	
	
	EXTI_InitStructure.EXTI_Line=FIRE_OUT_EXTI_LINE;
	EXTI_InitStructure.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger=FIRE_OUT_EXTI_TRIG;
	EXTI_InitStructure.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel=FIRE_OUT_EXTI_IRQN;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0x02;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0x02;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}/*
*********************************************************************************************************
*	�� �� ��: EXTI15_10_IRQHandler
*	����˵��: �ⲿ�ж�15-10�������
*	��    �Σ���
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void EXTI15_10_IRQHandler(void)
{
	if(EXTI_GetITStatus(VIBRATE_OUT_EXTI_LINE)!=RESET)
	{
			if(VIBRATE_OUT == VIBRATE_OUT_ACTIVE_LEVEL)
		{
			VIBRATE_OUT_flag=1;
		}
		EXTI_ClearITPendingBit(VIBRATE_OUT_EXTI_LINE);
	}
	if(EXTI_GetITStatus(PIR_OUT_EXTI_LINE)!=RESET)
	{
			if(PIR_OUT == PIR_OUT_ACTIVE_LEVEL)
		{
			PIR_OUT_flag=1;
		}
		EXTI_ClearITPendingBit(PIR_OUT_EXTI_LINE);
	}
	if(EXTI_GetITStatus(FIRE_OUT_EXTI_LINE)!=RESET)
	{
			if(FIRE_OUT == FIRE_OUT_ACTIVE_LEVEL)
		{
			FIRE_OUT_flag=1;
		}
		EXTI_ClearITPendingBit(FIRE_OUT_EXTI_LINE);
	}
	if(EXTI_GetITStatus(HALL_OUT_EXTI_LINE)!=RESET)
	{
			if(HALL_OUT == HALL_OUT_ACTIVE_LEVEL)
		{
			HALL_OUT_flag=1;
		}
		EXTI_ClearITPendingBit(HALL_OUT_EXTI_LINE);
	}
}


